# CL5D Hybrid Model – Core Implementation

> **Devise Foundation | Author: Mrinmoy Chakraborty**  
> DOI (under review): [10.5281/zenodo.17426250](https://doi.org/10.5281/zenodo.17426250)

---

## 🌌 Overview
The **CL5D Hybrid Model** unifies probabilistic reasoning, deterministic control, and fractal–entropy balance under the ConsciousLeaf 5D (CL5D) formalism.

It preserves all fractal geometrical and valence structures of the CL5D framework.

---

## 🧩 Core Layers

| Layer | Module | Description |
|-------|---------|-------------|
| Layer 1 | Probabilistic Valence System | Computes valence and risk disposition from noisy input data. |
| Layer 2 | Deterministic Core | Stabilizes control behavior through verification and conservative response. |
| Layer 3 | Conjugate Balance Analysis | Harmonizes probabilistic and deterministic outputs for stability. |

---

## 🧮 Example Usage

```python
from cl5d_hybrid_model.core import CL5DHybridModel
import numpy as np

model = CL5DHybridModel()
time_series = np.random.randn(1000)
H = model.calculate_hurst_exponent(time_series)
D = model.fractal_dimension_analysis(time_series)
valence = model.probabilistic_valence_system(time_series)
control = model.deterministic_core(valence, control_params={'alpha': 0.5})
balance = model.conjugate_balance_analysis(valence, control)
print(H, D, valence, balance)
```

---

## 🔬 Citation

> **Mrinmoy Chakraborty (2025)**, *CL5D Hybrid Model Core Implementation*,  
> Devise Foundation. Zenodo. DOI: [10.5281/zenodo.17426250](https://doi.org/10.5281/zenodo.17426250)

---

## ⚖️ License

MIT License © 2025 Mrinmoy Chakraborty  
Maintained by **Devise Foundation**.
